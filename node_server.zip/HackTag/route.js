const route=require('express').Router();
const { default: CSVError } = require('csvtojson/v2/CSVError');
const userOperation=require('./database');
var csv = require('csvtojson');  
const multer=require('multer');

var storage = multer.diskStorage({  
    destination:(req,file,cb)=>{  
        cb(null,'./public/uploads');  
    },  
    filename:(req,file,cb)=>{  
        cb(null,file.originalname);  
    }  
});  

var uploads = multer({storage:storage}); 
route.get('/getLoc',(req,res)=>{
    userOperation.getLocation({req,res});
    // res.status(200).send("Hi");
})


route.post('/upload',uploads.single('file'),(req,res) => {
    console.log(req.file);
    csv().fromFile(req.file).then((jsonOb) => {
        console.log(jsonOb);
        res.send(jsonOb);
    });
})

module.exports=route;