const express = require('express');
const cors=require('cors');
// const connectDB = require('./config/db');
// const path = require('path');
const app = express();
// connectDB();
// const route=require('express').Router();
// const userOperation=require('./database');

app.use(express.json({extended:false}));
app.use(cors());
app.use('/',require('./route'));


// var db=admin.database();
// app.use('/api/users',require('./routes/users'));
// app.use('/api/contacts',require('./routes/contacts'));
// app.use('/api/auth',require('./routes/auth'));


const PORT = process.env.PORT || 5000;

app.listen(PORT, () => console.log(`Server started at port ${PORT}`));