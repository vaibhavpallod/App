const admin=require('firebase-admin');

var serviceAccount = require('./admin.json');

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    databaseURL: "https://uber-hacktag-group-booking-default-rtdb.firebaseio.com/",
    authDomain: "uber-hacktag-group-booking.firebaseapp.com",
});

var db=admin.database();
var driverRef=db.ref("requestPool");

const userOperation={
    getLocation({req,res}){
        driverRef.child(req.headers['id']).once('value',function(snap){
            const {driverLatitude,driverLongitude, sourceLatitude,sourceLongitude, destinationLatitude, destinationLongitude,otp,status}=snap.val();
            res.status(200).json({"location":{
                driverLatitude,
                driverLongitude,sourceLatitude,sourceLongitude, destinationLatitude, destinationLongitude,otp:otp||"",status
            }});
        })
    }
}

module.exports=userOperation;